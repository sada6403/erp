---
name: android-compose-screen
description: Build or change a Jetpack Compose screen in the LankaHome app following the approved UI, MVVM + UDF, theme tokens, role rules and offline states. Use for any app UI work.
---

# Compose screen

## Structure (one feature folder per area)
```
feature/<area>/<screen>/
  <Screen>Route.kt      // collects state from ViewModel, handles navigation events
  <Screen>Screen.kt     // stateless UI: (state, onAction) -> Unit, has @Preview for both themes
  <Screen>ViewModel.kt  // @HiltViewModel, exposes StateFlow<UiState>, handles Action
  <Screen>UiState.kt    // data class + sealed Action
```

## Rules
1. Keep the approved demo layout. Reuse components from `core/designsystem` (cards, chips, badges,
   stat cards, bottom sheets). Do not create look-alike duplicates.
2. Colours only from `MaterialTheme.colorScheme` or `LocalExtendedColors` (accent, status colours).
   No `Color(0x…)` in feature code. Text sizes from `MaterialTheme.typography`.
3. Every data screen has 4 states: loading (skeleton), content, empty, error. Plus the offline banner
   from `core/network/ConnectivityBanner` when showing cached data (see skill `offline-cache`).
4. ViewModels read from repositories only (never Retrofit directly). Repositories return `Flow` from
   Room and expose `refresh()`.
5. Money: `Money.format(amount)` → `Rs 145,000`. Dates: `dd MMM yyyy`. Phone: `07X XXX XXXX`.
6. Strings in `res/values/strings.xml` + `values-ta` + `values-si`. No hard-coded user text.
7. Role guard: screens under `feature/agent` require role `agent`, `feature/smartbuy` dashboard requires
   `smartbuy` (join flow requires `customer`). The nav graph checks the session; the server enforces too.
8. Sensitive screens (wallet, draw video, NIC capture) call `SecureWindow()` → `FLAG_SECURE`.
9. Accessibility: 48 dp targets, `contentDescription` on icon buttons, no information by colour alone.
10. Add a `@Preview` for each theme (OliveYellow, PurplePink) and for the empty state.

## Done when
- Builds; previews render; checked on the emulator in both themes and in airplane mode;
  screenshot attached to your report.
