---
name: offline-cache
description: Make an app screen work from the Room cache when offline or when the server is down, and guard actions that need the server with the buy-later sheet. Use for any data screen or server action.
---

# Offline cache

Goal: products and personal data always show, even when the phone or the server is offline.
Actions that change money, stock or approvals never run offline.

## Read path (stale-while-revalidate)
1. Room entity + DAO for the data (`core/database`). Include `updatedAt` from the server and a
   `cachedAt` column.
2. Repository:
   ```kotlin
   fun products(categoryId: String?): Flow<List<Product>> = dao.observe(categoryId).map { it.toDomain() }
   suspend fun refresh(categoryId: String?) = runCatching {
       val since = dao.maxUpdatedAt(categoryId)
       val page = api.products(categoryId, updatedSince = since)
       db.withTransaction { dao.upsert(page.items.map { it.toEntity() }); dao.deleteIds(page.deletedIds) }
   }
   ```
3. ViewModel: collect the Flow for UI; call `refresh()` on open, on pull-to-refresh, on app foreground
   and when `/watermark` changes. A refresh failure never clears cached data. It only sets
   `isStale = true`.
4. Periodic: `CatalogSyncWorker` (WorkManager, every 6 h, network constraint) refreshes categories,
   products, banners, branches.
5. Images: Coil with a 250 MB disk cache; prefetch thumbnails of the first 2 pages per category.

## Connectivity & server status
- `ConnectivityMonitor` (NetworkCallback) → `isOnline: StateFlow<Boolean>`.
- `ServerStatusRepository` → `/status` (`ordering_enabled`, `maintenance_message`) cached in DataStore,
  refreshed on foreground. Treat timeouts/5xx as "server unreachable".
- `ConnectivityBanner`: "Offline — showing saved products · updated 2 h ago" (or maintenance message).

## Write path guard
Actions needing the server: place order, checkout quote, wallet pay, join request submit, password
change, email verify.
```kotlin
if (!online || !status.orderingEnabled) {
    showBuyLaterSheet(message = status.maintenanceMessage) // keeps the cart
    return
}
```
Buy-later sheet: "Ippo order panna mudiyaathu. Connection vantha udane notify pannuvom." with
**Notify me** → `NotifyWhenOnlineWorker` (one-time, network constraint) → local notification.
Never queue an order offline.

## Outbox (only these)
Agent delivery status + completion (OTP verified offline against `delivery_otp_hash`), wishlist toggles.
Outbox row = id (UUID event id), type, payload JSON, attempts. `OutboxWorker` uploads in order with the
event id as the idempotency key; server re-verifies.

## Done when
In airplane mode: home, categories, product detail, cart, my orders, statement, wallet history,
agent deliveries all render from cache; buy/wallet/join show the sheet; turning the network back on
refreshes without an app restart.
