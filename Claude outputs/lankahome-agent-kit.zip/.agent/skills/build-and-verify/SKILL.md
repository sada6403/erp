---
name: build-and-verify
description: Build, install and preview the LankaHome app on the Pixel_6 emulator or a phone, take verification screenshots, and produce debug/release builds. Use at the end of every app task.
---

# Build & verify

Environment: Windows, PowerShell. SDK `C:\Users\matha\AppData\Local\Android\Sdk`.
Package `com.aistudio.lankahome.qvxzmt`. AVD `Pixel_6`.

## Every app task
1. `.\gradlew.bat assembleDebug` and `.\gradlew.bat testDebugUnitTest` must pass.
2. Preview: run `preview.bat`. It starts Pixel_6 with a visible window (never `-no-window`), waits for
   `sys.boot_completed`, runs `installDebug`, launches the app, and also installs on a USB phone if
   one is connected.
3. Check the changed screens:
   - in both themes (Settings → App Theme)
   - for each role the screen belongs to (demo role bar)
   - in airplane mode, for data screens
4. Screenshots: `adb exec-out screencap -p > screenshots\<screen>-<theme>.png`. Attach them to the report.
5. Crash check: `adb logcat -d *:E | findstr qvxzmt`. It must be empty for your flow.

## Demo APK for Moni / client
Copy `app\build\outputs\apk\debug\app-debug.apk` to the project root as `LankaHome-preview.apk`.

## Release (Phase 4 only, ask first)
`.\gradlew.bat bundleRelease` with the upload keystore from `keystore.properties`. The keystore and
passwords are never committed. R8 is enabled; test the release build on a real device before upload.

## Backend changes in the same task
`npm run typecheck` in `erp/backend`. Point the debug app at the test backend
(`API_BASE_URL` in `local.properties`). Never test against the production tenant.
